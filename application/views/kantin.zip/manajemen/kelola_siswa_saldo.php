
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Saldo</h1>
                        
                    </div>

                    <!-- Content Row -->
                
                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-3 col-lg-3 col-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-success">Atur Nominal Saldo</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="oncard_template/#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Opsi lainnya:</div>
                                            <a class="dropdown-item" href="#">Reset</a>
                                            <a class="dropdown-item" href="#">Ke halaman dashboard</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Tutup</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 col-lg-12 col-12">
                                            <form id="mainx">
                                              <div class="form-group" id="typeinputan" >
                                                  
                                                  <?php 
                                                  if($nis==''){?>
                                                    <label for="mode" style="display:block; font-size:.7em; line-height:1em;">Metode pencarian data</label>
                                                    <div class="form-group">
                                                        <button type="button" class="btn btn-success btn-sm">Scan</button>
                                                        <button type="button" class="btn btn-outline-secondary btn-sm">Pilih manual</button>
                                                    </div>
                                                    
                                                    <label for="nisn" style="display:block; font-size:.7em; line-height:1em;">Pilih data siswa</label>
                                                    <select class="selectpicker" id="nisn" data-show-subtext="true" data-live-search="true" style="border-radius:0px;" required>
                                                    <option data-subtext="" value="">Pilih Data Dahulu</option>
                                                    <?php
                                                    foreach($getAllSiswa as $row){ if($row['id_user']!='' || $row['id_user']!=null){?>
                                                        <option data-subtext="<?=$row['nis'];?>" value="<?=$row['id_user'];?>"><?=$row['nama_siswa'];?></option>
                                                    <?php } } ?>
                                                
                                                <?php }else { ?>
                                                    <label for="nisn" style="display:block; font-size:.7em; line-height:1em;">Data siswa terpilih</label>
                                                    <input type="text" class="form-control" id="nisn" value="<?=$nis;?>" data-id="<?=$id_user;?>" placeholder="Rp0" readonly style="font-family: 'IBM Plex Mono', monospace;letter-spacing:.12em;border-radius:0px;" required>
                                                <?php } ?>
                                                
                                              </select>
                                              </div>
                                              
                                              <div class="form-group" >
                                                <label for="saldo" style="display:block; font-size:.7em; line-height:1em;">Saldo (Rp)</label>
                                                <input type="text" class="form-control" id="saldo" placeholder="Rp0" style="width:100%;font-family: 'IBM Plex Mono', monospace; font-size:3em; border-radius:0px;" required>
                                                
                                                
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12 col-12 mt-3">
                                                        <h6>Pilihan lain</h6>
                                                    </div>
                                                    <div class="col-md-4 col-lg-4 col-6 mt-2">
                                                        <button type="button" class="btn btn-sm btn-light saldoadd" style="font-size:.76em" value="20.000">Rp 20.000</button>
                                                    </div>
                                                    <div class="col-md-4 col-lg-4 col-6 mt-2">
                                                        <button type="button" class="btn btn-sm btn-light saldoadd" style="font-size:.76em" value="50.000">Rp 50.000</button>
                                                    </div>
                                                    <div class="col-md-4 col-lg-4 col-6 mt-2">
                                                        <button type="button" class="btn btn-sm btn-light saldoadd" style="font-size:.76em" value="100.000">Rp 100.000</button>
                                                    </div>
                                                    <div class="col-md-4 col-lg-4 col-6 mt-3">
                                                        <button type="button" class="btn btn-sm btn-light saldoadd" style="font-size:.76em" value="500.000">Rp 500.000</button>
                                                    </div>
                                                    <div class="col-md-4 col-lg-4 col-6 mt-3">
                                                        <button type="button" class="btn btn-sm btn-light saldoadd" style="font-size:.76em" value="1.000.000">Rp 1.000.000</button>
                                                    </div>
                                                    
                                                </div>
                                              
                                              </div>
                                              
                                              <div class="form-group">
                                                  <button type="button" class="btn btn-lg btn-success" id="btnSubmitForm"><i class="fa fa-plus"></i> Tambah Saldo</button>
                                              </div>
                                              
                                            </form>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                        
                        <div class="col-xl-5 col-lg-5 col-12" id="dataUserID">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-success">Data User</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="oncard_template/#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Opsi lainnya:</div>
                                            <a class="dropdown-item" href="#">Reset</a>
                                            <a class="dropdown-item" href="#">Ke halaman dashboard</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Tutup</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body" style="">
                                    <div class="row">
                                        <div class="col-md-12 col-lg-12 col-12 text-center">
                                            <img src="<?=base_url();?>engine/Assets/img/user/default.jpg" width="120" height="120" style="object-fit:cover; border-radius:7px; margin-bottom:3%;"/>
                                            <h4 id="val1">Loading...</h4>
                                            <h6 style="color:#636363;text-decoration:none; font-weight:normal;" id="val2">NISN : Loading...</h6>
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-12 text-center">
                                            <table class="table table-stripped text-left" width="100%" style="font-size:.8em;color:black;">
                                                <tr>
                                                    <td width="40%">Tanggal Lahir</td>
                                                    <td id="val3">Loading...</td>
                                                </tr>
                                                <tr>
                                                    <td width="100">Alamat sekarang</td>
                                                    <td id="val4">Loading...</td>
                                                </tr>
                                                <tr>
                                                    <td width="100">Jenis Kelamin</td>
                                                    <td id="val5">Loading...</td>
                                                </tr>
                                                <tr>
                                                    <td width="100">Tahun Masuk</td>
                                                    <td id="val6">Loading...</td>
                                                </tr>
                                                <tr>
                                                    <td width="100">Berada di kelas</td>
                                                    <td id="val7">Loading...</td>
                                                </tr>
                                                <tr>
                                                    <td width="100">Menggunakan oncard sejak</td>
                                                    <td id="val8">Loading...</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                        
                        <div class="col-xl-4 col-lg-4 col-12" id="SaldoID">
                            <div class="row">
                                
                                <div class="col-md-12 col-lg-12 col-12 text-center" style="margin-bottom:30px;">
                                    <div class="card shadow" style="padding-top:5%;padding-bottom:5%;background:url('https://www.payfazz.com/wp-content/uploads/2021/07/keuntungan-tersedia.svg');object-fit:cover; background-repeat:no-repeat;background-position:top right;">
                                    <font style=''>Saldo Terkini</font>
                                    <font class="text-warning" id="saldoTerkiniID" style="font-size:3em; font-weight:bold; font-family: 'IBM Plex Mono', monospace;text-shadow:0px 2px 0px #000">Loading...</font>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-success">Riwayat Penggunaan Saldo</h6>
                                    <p class="m-0 font-weight-bold text-secondary">10 transaksi terakhir</p>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="oncard_template/#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Opsi lainnya:</div>
                                            <a class="dropdown-item" href="#">Reset</a>
                                            <a class="dropdown-item" href="#">Ke halaman dashboard</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Tutup</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <div class="row" >
                                        <div class="col-md-12 col-lg-12 col-12 text-center" style="padding:0px!important;margin:0px!important;">
                                            <table class="table table-striped table-hover text-left" width="100%" style="font-size:.8em;color:black;">
                                                
                                                
                                                
                                                <tbody id="bodyTable"></tbody>
                                                
                                                
                                            </table>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                        <!-- Pie Chart -->
                        
                    </div>

                    <!-- Content Row -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


            
            
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Ponpes KH. Ahmad Dahlan - <?=date('Y');?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    
   

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    

    <!--<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>-->
    <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>-->

    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/popper.min.js"></script>
    
    <!-- tambahan ego -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js" integrity="sha512-bZS47S7sPOxkjU/4Bt0zrhEtWx0y0CRkhEp8IckzK+ltifIIE9EMIMTuT/mEzoIMewUINruDBIR/jJnbguonqQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!--<script src="https://kenwheeler.github.io/slick/slick/slick.js"></script>-->
    <script src="https://www.jqueryscript.net/demo/Bootstrap-4-Dropdown-Select-Plugin-jQuery/dist/js/bootstrap-select.js"></script>
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?=base_url();?>oncard_template/vendor/jquery/jquery.min.js"></script>
    <script src="<?=base_url();?>oncard_template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?=base_url();?>oncard_template/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?=base_url();?>oncard_template/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?=base_url();?>oncard_template/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?=base_url();?>oncard_template/js/demo/chart-area-demo.js"></script>
    <script src="<?=base_url();?>oncard_template/js/demo/chart-pie-demo.js"></script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.js"></script>
    <!-- ------------ -->
    
    
    <script type="text/javascript">
                
                            
                
                var check =$("#nisn").val();
                
                
                <?php
                
                if($nis!=''){ ?>
                    loadRiwayat(<?=$id_user;?>);
                <?php } ?>
                
                
                if(check){
                    const save = async (check)=>{
                      const posts = await axios.get('<?=api_url();?>siswa/getOne?nis='+check, {
                          headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                      }).catch((err)=>{
                          
                          $(".loading").fadeOut();
                          Swal.fire({
                              position: 'center',
                              icon: 'error',
                              title: 'Proses Gagal',
                              text: 'Terjadi kesalahan dalam memproses request Anda.',
                              showConfirmButton: true,
                              
                            });
                      });
                      
                      if(posts.status==200){
                          $(".loading").fadeOut();
                          
                          $('#val1').text(posts.data.nama_siswa);
                          $('#val2').text(posts.data.nis);
                          $('#val3').text(posts.data.tgl_lahir);
                          $('#val4').text(posts.data.alamat);
                          $('#val5').text(posts.data.jk);
                          $('#val6').text(posts.data.tahun_masuk);
                          $('#val7').text(posts.data.kelas);
                          $('#val8').text(posts.data.updated_at);
                        //   $('#val9').text(posts.data.nama_siswa);
                          
                          
                      }else {
                          $(".loading").fadeOut();
                          
                          
                          
                          
                      }
                  }
                  
                  save(check);
                }else {
                    $('#dataUserID').attr('style','display:none;');
                    $('#SaldoID').attr('style','display:none;');
                }
                
                
              
              
            var datatableset = $('#tblsiswa').DataTable( {
                // serverSide: true,
                processing: true,
                language: { search: "" ,searchPlaceholder: "Cari data siswa"},
                "oLanguage": {
                  "sInfo": "Menampilkan _START_ hingga _END_ dari _TOTAL_ total data.",
                  "oPaginate": {
                    "sPrevious": "Sebelumnya",
                    "sNext": "Berikutnya"
                  }
                },
                ajax: {
                    headers: {
                    'Accept': 'application/json','Authorization': 'Bearer '+ sessionStorage.getItem('_token')},
                    url: '<?=api_url();?>siswa/get-table',
                    type: 'GET'
                }
                
            } );

        function loadRiwayat(check){
              const save = async (check)=>{
              const posts = await axios.get('<?=api_url();?>siswa/get-siswa-in-relation/'+check, {
                  headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
              }).catch((err)=>{
                  
                  $(".loading").fadeOut();
                  Swal.fire({
                      position: 'center',
                      icon: 'error',
                      title: 'Proses Gagal',
                      text: 'Terjadi kesalahan dalam memproses request Anda.',
                      showConfirmButton: true,
                      
                    });
              });
              
              if(posts.status==200){
                  $(".loading").fadeOut();
                  
                //   console.log(posts);
                //   return false;
                
                $('#saldoTerkiniID').text("Rp "+formatRupiah(posts.data.response.result.saldo));
                
                if(posts.data.response.riwayat_transaksi.length>0){
                    let sintaks='';
                    let no = 1;
                    posts.data.response.riwayat_transaksi.map((mapping,i)=>{
                        sintaks+=`
                         <tr>
                        <td width="5%">${no++}</td>
                        <td >${mapping.pesan}</td>
                        <td class="text-right">${formatRupiah(mapping.jumlah_aksi,'Rp')}</td>
                        </tr>
                        `;
                    });
                    
                    $('#bodyTable').html(sintaks);
                }
                  
              }else {
                  $(".loading").fadeOut();
                  
                  
                  
                  
              }
          }
          
          
          save(check);
            
        }
        $('#nisn').on('change', function() {
                
              
              
            
              $('#dataUserID').attr('style','display:block;');
              $('#SaldoID').attr('style','display:block;');
              
              var check = $('option:selected',this).attr("data-subtext");
            //   var checkID = $('option:selected',this).attr("value");
              
              loadRiwayat(this.value);
              
              const save = async (check)=>{
              const posts = await axios.get('<?=api_url();?>siswa/getOne?nis='+check, {
                  headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
              }).catch((err)=>{
                  
                  $(".loading").fadeOut();
                  Swal.fire({
                      position: 'center',
                      icon: 'error',
                      title: 'Proses Gagal',
                      text: 'Terjadi kesalahan dalam memproses request Anda.',
                      showConfirmButton: true,
                      
                    });
              });
              
              if(posts.status==200){
                  $(".loading").fadeOut();
                  
                  $('#val1').text(posts.data.nama_siswa);
                  $('#val2').text(posts.data.nis);
                  $('#val3').text(posts.data.tgl_lahir);
                  $('#val4').text(posts.data.alamat);
                  $('#val5').text(posts.data.jk);
                  $('#val6').text(posts.data.tahun_masuk);
                  $('#val7').text(posts.data.kelas);
                  $('#val8').text(posts.data.updated_at);
                //   $('#val9').text(posts.data.nama_siswa);
                  
                  
              }else {
                  $(".loading").fadeOut();
                  
                  
                  
                  
              }
          }
          
          save(check);
            });
        
    
        function logoutBtn() {
            sessionStorage.removeItem('_token');
            window.location.href='<?=base_url("Login/logoutUser");?>';
        }
        $(document).ready(function() {
            
        });
        
        function updateSiswa(str){
            
            $('#btnSubmitForm').val("update");
            $('#nisn').attr('disabled',true);
            
            $('#exampleModalCenter').modal('show');
            
            
            $('#jdlmodal').text("Update Data Siswa");
            
            const save = async (str)=>{
              const posts = await axios.get('<?=api_url();?>siswa/getOne?nis='+str, {
                      headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                  }).catch((err)=>{
                  
                  $(".loading").fadeOut();
                  
                  
              });
              
              if(posts.status==200){
                  
                  document.getElementById("xmein").reset();
                    
                    $(".loading").fadeOut();
                    
                    $('#nisn').text(posts.data.nis);
                    $('#namakl').text(posts.data.nama_siswa);
                    $('#tgllhr').text(posts.data.tgl_lahir);
                    if($('#gridRadios1').val()==posts.data.jk){
                        $("#gridRadios1").prop("checked", true);
                    }else {
                        $("#gridRadios2").prop("checked", true);
                    }
                    $('#agama').text(posts.data.agama);
                    $('#tahunmmsk').text(posts.data.tahun_masuk);
                    $('#alamat').text(posts.data.alamat);
                  
              }else {
                  $(".loading").fadeOut();
                  
              }
          }
          
          save(str);
        }
        
        $('#exampleModalCenter').on('hidden.bs.modal', function () {
          $('#btnSubmitForm').val("add");
          $('#jdlmodal').text("Tambah Data Siswa");
          $('#mainx').trigger("reset");
          $('#nisn').attr('disabled',false);
        });
        
        function addSaldoSiswa(str){
            $(".loading").fadeIn();
        }
        
        function deleteSiswa(str){
            Swal.fire({
              position: 'top',
              icon: 'info',
              title: '<h5>Yakin ingin menghapus data ini?</h5>',
              html: '<h6>Data yang telah dihapus tidak dapat dikembalikan lagi. Harap hati - hati dan teliti dalam memilih data yang ingin dihapus ya.</h6>',
              showConfirmButton: true,
              showDenyButton: true,
              showCancelButton: false,
              confirmButtonText: 'Batal menghapus',
              denyButtonText: `Yakin, hapus sekarang`,
              
            }).then((result)=>{
              if (result.isConfirmed) {
                
              } else if (result.isDenied) {

              const save = async (str)=>{
                  const posts = await axios.delete('<?=api_url();?>siswa/delete/'+str, {
                      headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                  }).catch((err)=>{
                      
                      $(".loading").fadeOut();
                      Swal.fire({
                          position: 'center',
                          icon: 'error',
                          title: 'Proses Gagal',
                          text: 'Terjadi kesalahan dalam memproses request Anda.',
                          showConfirmButton: true,
                          
                        });
                  });
                  
                  if(posts.status==200){
                      
                      if(posts.data.status==true){
                        $(".loading").fadeOut();
                        
                        Swal.fire({
                          position: 'top-center',
                          icon: 'success',
                          title: 'Dihapus!',
                          text: 'Data berhasil dihapus',
                          showConfirmButton: false,
                          timer: 2000
                          
                        });
                        
                        datatableset.ajax.reload();

                        
                      }else {
                          $(".loading").fadeOut();
                            Swal.fire({
                              position: 'center',
                              icon: 'error',
                              title: 'Gagal Proses',
                              text: 'Data tidak dapat diproses dalam saat ini, ulangi dilain waktu.',
                              showConfirmButton: true,
                              
                            });
                      }
                      
                  }else {
                      $(".loading").fadeOut();
                      
                  }
              }
              
              save(str);
              }
            });
        }
        
        
        $(".loading").hide();

        $('#btnSubmitForm').on('click', function(){
            
                    

                    $(".loading").fadeIn();
                
                
                    //validasi formulir terlebih dahulu
                    var allAreFilled = true;
                    document.getElementById("mainx").querySelectorAll("[required]").forEach(function(i) {
                      if (!allAreFilled) return;
                      if (!i.value) allAreFilled = false;
                      if (i.type === "radio") {
                        var radioValueCheck = false;
                        document.getElementById("mainx").querySelectorAll('[name=${i.name}]').forEach(function(r) {
                          if (r.checked) radioValueCheck = true;
                        })
                        allAreFilled = radioValueCheck;
                      }
                    })
                    if (!allAreFilled) {
                        Swal.fire({
                          position: 'top-end',
                          icon: 'error',
                          title: '<h6>Data tidak lengkap</h6>',
                          html: '<h6>Harap isi semua formulir inputan yang dibutuhkan.</h6>',
                          showConfirmButton: false,
                          timer: 2000
                          
                        });
                        $(".loading").fadeOut();
                    }else {
                        
                      
                      
                      var nisn = $("#nisn").data('id');
                      var saldo = $("#saldo").val();
                      var aksi = "tambah";
                      var pesan = "menambahkan saldo dari admin sekolah";
                      
                      saldo = saldo.replace(/\./g,'');
                      
                      
                      var form_data = new FormData();     
                      form_data.append('id_user', nisn);
                      form_data.append('saldo', saldo);
                      form_data.append('aksi', aksi);
                      form_data.append('pesan', pesan);
                      
                      const save = async (form_data)=>{
                          const posts = await axios.post('<?=api_url();?>auth/user-upsaldo', form_data, {
                              headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                          }).catch((err)=>{
                              
                              $(".loading").fadeOut();
                              Swal.fire({
                                  position: 'center',
                                  icon: 'error',
                                  title: 'Gagal Memproses',
                                  text: 'Terjadi kesalahan dalam proses data.',
                                  showConfirmButton: true,
                                  
                                });
                          });
                          
                          if(posts.status==200){
                              
                              if(posts.data.status==true){
                                $(".loading").fadeOut();
                    
                    
                    
                                Swal.fire({
                                  position: 'top-end',
                                  icon: 'success',
                                  title: '<h6>Berhasil Menambah Saldo</h6>',
                                  html: '<h6>Data sudah tersimpan</h6>',
                                  showConfirmButton: false,
                                  timer: 2000
                                  
                                });
                                
                                loadRiwayat(nisn);
                                
                                // $('#tblsiswa').ajax.reload();
                                datatableset.ajax.reload();
                                
                              }else {
                                  $(".loading").fadeOut();
                                Swal.fire({
                                  position: 'center',
                                  icon: 'error',
                                  title: 'Gagal Menyimpan',
                                  text: 'Data tidak dapat disimpan dalam saat ini, ulangi dilain waktu.',
                                  showConfirmButton: true,
                                  
                                });
                              }
                              
                          }else {
                              $(".loading").fadeOut();
                              Swal.fire({
                                  position: 'center',
                                  icon: 'error',
                                  title: 'Gagal Menyimpan',
                                  text: 'Data sudah ada dan tidak dapat ditambahkan lagi',
                                  showConfirmButton: true,
                                  
                                });
                          }
                      }
                      
                      save(form_data);
   
                    }

        });
        
        $("#errmsgs").fadeOut();

        $('#saldo').keyup(function(event) {
        
          // skip for arrow keys
          if(event.which >= 37 && event.which <= 40) return;
        
          // format number
          $(this).val(function(index, value) {
            return value
            .replace(/\D/g, "")
            .replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            ;
          });
        });
        
        $('.saldoadd').on('click', function(){
            $('#saldo').val($(this).val());
            
        });
        
        /* Fungsi formatRupiah */
        function formatRupiah(angka, prefix){
        	var number_string = angka.replace(/[^,\d]/g, '').toString(),
        	split   		= number_string.split(','),
        	sisa     		= split[0].length % 3,
        	rupiah     		= split[0].substr(0, sisa),
        	ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);
        
        	// tambahkan titik jika yang di input sudah menjadi angka ribuan
        	if(ribuan){
        		separator = sisa ? '.' : '';
        		rupiah += separator + ribuan.join('.');
        	}
        
        	rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        	return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
        }
        
        
        
    </script>
    
    

</body>
<!-- Mirrored from colorlib.com/polygon/admindek/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Dec 2019 16:08:25 GMT -->

</html>