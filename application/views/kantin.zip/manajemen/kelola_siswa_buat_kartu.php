                <!-- Begin Page Content -->
                <div class="container-fluid" style="font-family: 'Nunito', sans-serif!important;">

                    <!-- Page Heading -->
                    <div class="mb-4 text-center">
                        
                        
                    </div>

                    <!-- Content Row -->
                
                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12 col-12">
                            <div class="">
                                <div class="row justify-content-center ">
                                    <div class="col-md-4 text-center">
                                        <img src="<?=base_url();?>assets/svg/process-animate.svg" width="80%"/>
                                    </div>
                                    <div class="col-md-8" style="background:#fff;padding-top:50px; margin-top:-50px;">
                                        <h1 class="h3 mb-0  text-center" style="font-weight:900;"><img src="<?=base_url();?>assets/svg/credit-card.svg" width="40" class="mr-4"/>Instalasi <font style="color:#00c88c;">Kartu</font> Baru</h1>
                                        <div class="page-ath-wrap">
                                            <div class="page-ath-content register-form-content">
                                                <div class="page-ath-form">
                                                    <div class="form-align-box">
                                                        <div class="wizard">
                                                          <div class="progress" style="height: 30px;">
                                                                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="1" aria-valuemin="1" aria-valuemax="4" style="width: 25%;">
                                                                  Langkah 1 dari 4
                                                                </div>
                                                            </div>
                                                            <form role="form" id="mainx" action="index.html" class="register-wizard-box">
                                                                <div class="tab-content" id="main_form">
                                                                    
                                                                    <div class="tab-pane active text-center" role="tabpanel" id="step1">
                                                                        <div class="form-input-steps">
                                                                            <div id="stepscan1">
                                                                            <h3 style="margin:0px;line-height:1em;padding:0px;">Scan Kartu</h3>
                                                                            <h4 style="margin:0px;">Tempelkan kartu pada mesin pemindai kartu sekarang!</h4>
                                                                            <img src="https://cdn.dribbble.com/users/1046956/screenshots/4468756/qrscananimation.gif" width="30%" class="mb-1"/>
                                                                            
                                                                            <p><i class="fa fa-dot-circle text-success mr-1"></i>Perangkat ready...</p>
                                                                            </div>
                                                                            
                                                                            <div id="stepscan2" style="display:none;">
                                                                            <div style="border:1px solfid #f0f0f0; padding:20px;padding-bottom:80px">
                                                                                <font class="mb-3" style="border-radius:100px; background-color:#00c88c;color:#fff;padding:10px; padding-left:2em; padding-right:2em; font-size:.6em; border-bottom-left-radius:0px; border-bottom-right-radius:0px;">ID KARTU TERDETEKSI</font>
                                                                                
                                                                                <img src="https://baitulquran.ponpes.id/wp-content/uploads/2021/01/streaq-icon-seamless.gif" width="300" style="display:block;margin:auto;">
                                                                                
                                                                                <div id="output" class="mt-3" style="display:block;font-family: 'Orbitron', sans-serif; letter-spacing:2px; text-transform:uppercase; font-size:2em; font-weight:bold; "></div>
                                                                                
                                                                            </div>
                                                                            </div>
                                                                            
                                                                            
                                                                        </div>
                                                                        <ul class="list-inline text-right">
                                                                            <li>
                                                                                <button type="button" class="step-btn prev-step"><i class="fa fa-chevron-left"></i><span>Kembali</span></button>
                                                                            </li>
                                                                            <li>
                                                                                <button type="button" class="step-btn next-step"><span>Lanjut</span><i class="fa fa-chevron-right"></i></button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="tab-pane" role="tabpanel" id="step2">
                                                                        <div class="form-input-steps mt-5">
                                                                            <h4>Tentukan Pengguna</h4>
                                                                            <h3>Pilih salah satu dari pengguna yang terdaftar</h3>
                                                                            <div class="form-group" >
                                                                                <label for="nisn" style="display:block; font-size:.7em; line-height:1em;">Pilih data siswa</label>
                                                                                <select class="selectpicker" id="nisn" data-show-subtext="true" data-live-search="true" style="border-radius:0px;" required>
                                                                                <option data-subtext="" data-nama="" value="">Pilih Data Dahulu</option>
                                                                                <?php
                                                                                foreach($getAllSiswa as $row){ if($row['id_user']=='' || $row['id_user']==null){?>
                                                                                    <option data-subtext="<?=$row['nis'];?>" data-nama="<?=$row['nama_siswa'];?>" value="<?=$row['nis'];?>"><?=$row['nama_siswa'];?></option>
                                                                                <?php } } ?>
                                                                                </select>
                                                                                
                                                                                <p class="mt-2">Tidak menemukan data pengguna yang diinginkan? <a href="<?=base_url('Manajemen/siswa?add=true');?>">Tambahkan pengguna baru</a> sekarang</p>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <ul class="list-inline text-right">
                                                                            <li>
                                                                                <button type="button" class="step-btn prev-step"><i class="fa fa-chevron-left"></i><span>Kembali</span></button>
                                                                            </li>
                                                                            <li>
                                                                                <button type="button" class="step-btn next-step"><span>Lanjut</span><i class="fa fa-chevron-right"></i></button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="tab-pane" role="tabpanel" id="step3">
                                                                        <div class="form-input-steps mt-5">
                                                                            <h4>Tetapkan saldo awal</h4>
                                                                            <h3>Apabila tidak ingin mengisi saldo saat ini, silahkan isi dengan angka nol (0)</h3>
                                                                            <div class="form-group" >
                                                                                <label for="saldo" style="display:block; font-size:.7em; line-height:1em;">Saldo (Rp)</label>
                                                                                <input type="text" class="form-control" id="saldo" placeholder="Rp0" style="width:100%;font-family: 'IBM Plex Mono', monospace; font-size:3em; border-radius:0px;" required>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <ul class="list-inline text-right">
                                                                            <li>
                                                                                <button type="button" class="step-btn prev-step"><i class="fa fa-chevron-left"></i><span>Kembali</span></button>
                                                                            </li>
                                                                            <li>
                                                                                <button type="button" class="step-btn next-step" id="goConfirm"><span>Lanjut</span><i class="fa fa-chevron-right"></i></button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="tab-pane" role="tabpanel" id="step4">
                                                                        <div class="form-input-steps">
                                                                            <div id="stx1">
                                                                                <h4>Summary</h4>
                                                                                <h3>Konfirmasi Kembali Data Berikut</h3>
                                                                                
                                                                                <table class="table table-striped">
                                                                                    <tr>
                                                                                        <td width="35%">Nama</td>
                                                                                        <td id="namaset">Loading...</td>
                                                                                    </tr>
                                                                                    
                                                                                    <tr>
                                                                                        <td width="35%">NIS</td>
                                                                                        <td id="nisset">Loading...</td>
                                                                                    </tr>
                                                                                    
                                                                                    <tr>
                                                                                        <td width="35%">Saldo Awal</td>
                                                                                        <td id="saldoset">Loading...</td>
                                                                                    </tr>
                                                                                    
                                                                                    <tr>
                                                                                        <td width="35%">Nomor Kartu</td>
                                                                                        <td class="nokartu">Loading...</td>
                                                                                    </tr>
                                                                                </table>
                                                                                
                                                                                <h5 class="mt-5 mb-3">Dengan ini data pengguna tersebut akan dihubungkan ke kartu dengan nomor <strong class="nokartu">Loading...</strong><br/>Tekan tombol <strong>Selesai</strong> untuk menginisiasi penginstallan kartu terhadap data pengguna tersebut.</h5>
                                                                                
                                                                            </div>
                                                                            
                                                                            <div id="stx2" class="text-center mt-5">
                                                                                <img src="https://cdn.neow.in/news/images/uploaded/2019/09/1567614758_data_portabilityprivacy_banner_003_256_30fps.gif" width="60%">
                                                                                <h6 class="text-dark" style="font-weight:bold;">Harap menunggu beberapa saat</h6>
                                                                                <h5 class="text-dark" style="font-weight:bold;">Sedang menginstall kartu...</h5>
                                                                            </div>
                                                                        </div>
                                                                        <ul class="list-inline text-right">
                                                                            <li>
                                                                                <button type="button" class="step-btn prev-step"><i class="fa fa-chevron-left"></i><span>Kembali</span></button>
                                                                            </li>
                                                                            <li>
                                                                                <button id="btnSubmitForm" type="button" class="step-btn next-step"><span>Selesai</span><i class="fa fa-chevron-right"></i></button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </form>
                                                            <div class="wizard-inner">
                                                                <ul class="nav nav-tabs" role="tablist">
                                                                    <li role="presentation">
                                                                        <a href="#step1" class="active" data-toggle="tab" aria-controls="step1" role="tab" aria-expanded="true" data-step="1">
                                                                            <span class="round-tab">1</span>
                                                                        </a>
                                                                    </li>
                                                                    <li role="presentation">
                                                                        <a href="#step2" class="disabled" data-toggle="tab" aria-controls="step2" role="tab" aria-expanded="false" data-step="2">
                                                                            <span class="round-tab">2</span>
                                                                        </a>
                                                                    </li>
                                                                    <li role="presentation">
                                                                        <a href="#step3" class="disabled" data-toggle="tab" aria-controls="step3" role="tab" data-step="3">
                                                                            <span class="round-tab">3</span>
                                                                        </a>
                                                                    </li>
                                                                    <li role="presentation">
                                                                        <a href="#step4" class="disabled" data-toggle="tab" aria-controls="step4" role="tab" data-step="4"> 
                                                                           <span class="round-tab">4</span>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                          
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                        <!-- Pie Chart -->
                        
                    </div>

                    <!-- Content Row -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


            
            
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Ponpes KH. Ahmad Dahlan - <?=date('Y');?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    
   

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    

    <!--<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>-->
    <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>-->

    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/popper.min.js"></script>
    
    <!-- tambahan ego -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js" integrity="sha512-bZS47S7sPOxkjU/4Bt0zrhEtWx0y0CRkhEp8IckzK+ltifIIE9EMIMTuT/mEzoIMewUINruDBIR/jJnbguonqQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!--<script src="https://kenwheeler.github.io/slick/slick/slick.js"></script>-->
    <script src="https://www.jqueryscript.net/demo/Bootstrap-4-Dropdown-Select-Plugin-jQuery/dist/js/bootstrap-select.js"></script>
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?=base_url();?>oncard_template/vendor/jquery/jquery.min.js"></script>
    <script src="<?=base_url();?>oncard_template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?=base_url();?>oncard_template/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?=base_url();?>oncard_template/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?=base_url();?>oncard_template/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?=base_url();?>oncard_template/js/demo/chart-area-demo.js"></script>
    <script src="<?=base_url();?>oncard_template/js/demo/chart-pie-demo.js"></script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.js"></script>
    <!-- ------------ -->
    
    
    <script type="text/javascript">

        $('#stepscan2').attr('style','display:none');
        setTimeout(function() {
          $('#stepscan1').attr('style','display:none');
          $('#stepscan2').attr('style','display:block');
          $('#stepscan2').fadeIn();
          runTextSearchCard();
        }, 3000);
        
        function logoutBtn() {
            sessionStorage.removeItem('_token');
            window.location.href='<?=base_url("Login/logoutUser");?>';
        }
        $(document).ready(function() {
            
        });
        
        $(".loading").hide();
        $('#stx2').fadeOut();
        
        $('#btnSubmitForm').on('click', function(){
            
                    

                    // $(".loading").fadeIn();
                    
                    $('#stx1').attr('style','display:none');
                    $('#stx2').attr('style','display:block');
                    
                    
                
                
                    //validasi formulir terlebih dahulu
                    var allAreFilled = true;
                    document.getElementById("mainx").querySelectorAll("[required]").forEach(function(i) {
                      if (!allAreFilled) return;
                      if (!i.value) allAreFilled = false;
                      if (i.type === "radio") {
                        var radioValueCheck = false;
                        document.getElementById("mainx").querySelectorAll('[name=${i.name}]').forEach(function(r) {
                          if (r.checked) radioValueCheck = true;
                        })
                        allAreFilled = radioValueCheck;
                      }
                    })
                    if (!allAreFilled) {
                        Swal.fire({
                          position: 'top-end',
                          icon: 'error',
                          title: '<h6>Data tidak lengkap</h6>',
                          html: '<h6>Harap isi semua formulir inputan yang dibutuhkan.</h6>',
                          showConfirmButton: false,
                          timer: 2000
                          
                        });
                        $(".loading").fadeOut();
                    }else {
                        
                        setTimeout(function() {
                            
                            let namaGet = $('option:selected',$('#nisn')).attr("data-nama");
                            let nisGet = $('option:selected',$('#nisn')).attr("data-subtext");
                            
                            let parseSaldo = $('#saldo').val();
                            parseSaldo = parseSaldo.replace(/\./g,'');
                            
                              var form_data = new FormData();     
                              form_data.append('table', 'siswa');
                              form_data.append('primary', nisGet);
                              form_data.append('saldo', parseSaldo);
                              form_data.append('code_generate', $('#output').text());
                              
                              const save = async (form_data)=>{
                                  const posts = await axios.post('<?=api_url();?>auth/user-join', form_data, {
                                      headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                                  }).catch((err)=>{
                                      
                                      $(".loading").fadeOut();
                                      Swal.fire({
                                          position: 'center',
                                          icon: 'error',
                                          title: 'Gagal Memproses',
                                          text: 'Terjadi kesalahan dalam proses data.',
                                          showConfirmButton: true,
                                          
                                        });
                                        
                                        var $active = $('.wizard .nav-tabs li a.active');
                                        prevTab($active);
                                        
                                        var $active2 = $('.wizard .nav-tabs li a.active');
                                        prevTab($active2);
                                        
                                        var $active3 = $('.wizard .nav-tabs li a.active');
                                        prevTab($active3);
                                  });
                                  
                                  if(posts.status==200){
                                      
                                      if(posts.data.status==true){
                                        $(".loading").fadeOut();
                            
                            
                            
                                        Swal.fire({
                                          position: 'top-end',
                                          icon: 'success',
                                          title: '<h6>Inisiasi Berhasil</h6>',
                                          html: '<h6>Data sudah tersimpan</h6>',
                                          showConfirmButton: false,
                                          timer: 2000
                                          
                                        });
                                        
                                        $('#stx1').attr('style','display:block');
                                        $('#stx2').attr('style','display:none');
                                        
                                        var $active = $('.wizard .nav-tabs li a.active');
                                        prevTab($active);
                                        
                                        var $active2 = $('.wizard .nav-tabs li a.active');
                                        prevTab($active2);
                                        
                                        var $active3 = $('.wizard .nav-tabs li a.active');
                                        prevTab($active3);
                                        
                                        $('#stepscan1').attr('style','display:block');
                                        $('#stepscan2').attr('style','display:none');
                                        
                                      }else {
                                          $(".loading").fadeOut();
                                        Swal.fire({
                                          position: 'center',
                                          icon: 'error',
                                          title: 'Gagal Menyimpan',
                                          text: 'Data tidak dapat disimpan dalam saat ini, ulangi dilain waktu.',
                                          showConfirmButton: true,
                                          
                                        });
                                        
                                        $('#stx1').attr('style','display:block');
                                        $('#stx2').attr('style','display:none');
                                      }
                                      
                                  }else {
                                      $(".loading").fadeOut();
                                      Swal.fire({
                                          position: 'center',
                                          icon: 'error',
                                          title: 'Gagal Menyimpan',
                                          text: 'Data sudah ada dan tidak dapat ditambahkan lagi',
                                          showConfirmButton: true,
                                          
                                        });
                                        
                                        $('#stx1').attr('style','display:block');
                                        $('#stx2').attr('style','display:none');
                                  }
                              }
                              
                              save(form_data);
           
              
                        }, 5000);
                      
                      
                    }

        });
        
        $("#errmsgs").fadeOut();

        $('#saldo').keyup(function(event) {
        
          // skip for arrow keys
          if(event.which >= 37 && event.which <= 40) return;
        
          // format number
          $(this).val(function(index, value) {
            return value
            .replace(/\D/g, "")
            .replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            ;
          });
        });
        
        $('.saldoadd').on('click', function(){
            $('#saldo').val($(this).val());
            
        });
        
        /* Fungsi formatRupiah */
        function formatRupiah(angka, prefix){
        	var number_string = angka.replace(/[^,\d]/g, '').toString(),
        	split   		= number_string.split(','),
        	sisa     		= split[0].length % 3,
        	rupiah     		= split[0].substr(0, sisa),
        	ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);
        
        	// tambahkan titik jika yang di input sudah menjadi angka ribuan
        	if(ribuan){
        		separator = sisa ? '.' : '';
        		rupiah += separator + ribuan.join('.');
        	}
        
        	rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        	return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
        }
        
        
        
        
        // ------------register-steps--------------
        $(document).ready(function () {
            $('.nav-tabs > li a[title]').tooltip();
            //Wizard
            $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                var $target = $(e.target);
                if ($target.hasClass('disabled')) {
                    return false;
                }
              
                // handle with prgressbar 
                var step = $(e.target).data('step');
                var percent = (parseInt(step) / 4) * 100;
                $('.progress-bar').css({ width: percent + '%' });
                $('.progress-bar').text('Langkah ' + step + ' dari 4');
              
            });
        
            $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {
                var $target = $(e.target);
                $target.parent().addClass('active');
            });
        
            $('a[data-toggle="tab"]').on('hide.bs.tab', function (e) {
                var $target = $(e.target);
                $target.parent().removeClass('active');
            });
        
        
            $(".next-step").click(function (e) {
                var $active = $('.wizard .nav-tabs li a.active');
                $active.parent().next().children().removeClass('disabled');
                $active.parent().addClass('done');
                nextTab($active);
            });
        
            $(".prev-step").click(function (e) {
                var $active = $('.wizard .nav-tabs li a.active');
                prevTab($active);
            });
        });
        
        function nextTab(elem) {
            $(elem).parent().next().find('a[data-toggle="tab"]').click();
        }
        function prevTab(elem) {
            $(elem).parent().prev().find('a[data-toggle="tab"]').click();
        }


        
                
        function runTextSearchCard(){
            var theLetters = "abcdefghijklmnopqrstuvwxyz#%&^+=-"; //You can customize what letters it will cycle through
            var ctnt = "acbesksknjas@04rkd"; // Your text goes here
            var speed = 10; // ms per frame
            var increment = 3; // frames per step. Must be >2
            
                
            var clen = ctnt.length;       
            var si = 0;
            var stri = 0;
            var block = "";
            var fixed = "";
            //Call self x times, whole function wrapped in setTimeout
            (function rustle (i) {          
            setTimeout(function () {
              if (--i){rustle(i);}
              nextFrame(i);
              si = si + 1;        
            }, speed);
            })(clen*increment+1); 
            function nextFrame(pos){
              for (var i=0; i<clen-stri; i++) {
                //Random number
                var num = Math.floor(theLetters.length * Math.random());
                //Get random letter
                var letter = theLetters.charAt(num);
                block = block + letter;
              }
              if (si == (increment-1)){
                stri++;
              }
              if (si == increment){
              // Add a letter; 
              // every speed*10 ms
              fixed = fixed +  ctnt.charAt(stri - 1);
              si = 0;
              }
              $("#output").html(fixed + block);
              block = "";
            }
        }
        
        
        $('#goConfirm').on('click', function(){
            
             //validasi formulir terlebih dahulu
            var allAreFilled = true;
            document.getElementById("mainx").querySelectorAll("[required]").forEach(function(i) {
              if (!allAreFilled) return;
              if (!i.value) allAreFilled = false;
              if (i.type === "radio") {
                var radioValueCheck = false;
                document.getElementById("mainx").querySelectorAll('[name=${i.name}]').forEach(function(r) {
                  if (r.checked) radioValueCheck = true;
                })
                allAreFilled = radioValueCheck;
              }
            })
            if (!allAreFilled) {
                Swal.fire({
                  position: 'top-end',
                  icon: 'error',
                  title: '<h6>Data tidak lengkap</h6>',
                  html: '<h6>Harap isi semua formulir inputan yang dibutuhkan.</h6>',
                  showConfirmButton: false,
                  timer: 2000
                  
                });
                $(".loading").fadeOut();
                $("#btnSubmitForm").attr('disabled','disabled');
            }else {
                let namaGet = $('option:selected',$('#nisn')).attr("data-nama");
                let nisGet = $('option:selected',$('#nisn')).attr("data-subtext");
    
                $('#namaset').text(namaGet);
                $('#nisset').text(nisGet);
                $('#saldoset').text("Rp "+$('#saldo').val());
                $('.nokartu').text($('#output').text());
                
                $("#btnSubmitForm").attr('disabled',false);
            }
            
            
        });
        
        
    </script>

</body>


</html>