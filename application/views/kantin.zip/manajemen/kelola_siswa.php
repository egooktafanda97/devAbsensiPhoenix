
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Siswa</h1>
                        <a href="oncard_template/#" data-toggle="modal" data-target="#exampleModalCenter" class="d-none d-sm-inline-block btn btn-success shadow-sm"><i
                                class="fa fa-plus fa-sm text-white-50"></i> Buat Akun Siswa</a>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Total Siswa Aktif</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">513</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fa fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Memiliki Kartu OnCard (500/513)
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">97%</div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-success" role="progressbar"
                                                            style="width: 97%" aria-valuenow="97" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Ketersediaan Kartu OnCard</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">66</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fa fa-credit-card fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Pending Requests</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12 col-12">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-success">Data Seluruh Siswa</h6>
                                    <div class="dropdown no-arrow">
                                        <a class="dropdown-toggle" href="oncard_template/#" role="button" id="dropdownMenuLink"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                            aria-labelledby="dropdownMenuLink">
                                            <div class="dropdown-header">Dropdown Header:</div>
                                            <a class="dropdown-item" href="oncard_template/#">Action</a>
                                            <a class="dropdown-item" href="oncard_template/#">Another action</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="oncard_template/#">Something else here</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                    <table id="tblsiswa" class="display">
                                        <thead>
                                            <tr>
                                                <th>NISN</th>
                                                <th>Nama Siswa</th>
                                                <th>Tanggal Lahir</th>
                                                <th>Umur</th>
                                                <th>Kelas</th>
                                                <th>Tindakan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Pie Chart -->
                        
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">

                            <!-- Project Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-success">Projects</h6>
                                </div>
                                <div class="card-body">
                                    <h4 class="small font-weight-bold">Server Migration <span
                                            class="float-right">20%</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-danger" role="progressbar" style="width: 20%"
                                            aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Sales Tracking <span
                                            class="float-right">40%</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 40%"
                                            aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Customer Database <span
                                            class="float-right">60%</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar" role="progressbar" style="width: 60%"
                                            aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Payout Details <span
                                            class="float-right">80%</span></h4>
                                    <div class="progress mb-4">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 80%"
                                            aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <h4 class="small font-weight-bold">Account Setup <span
                                            class="float-right">Complete!</span></h4>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 100%"
                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Color System -->
                    

                        </div>

                        <div class="col-lg-6 mb-4">

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-success">Illustrations</h6>
                                </div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;"
                                            src="<?=base_url();?>oncard_template/img/undraw_posting_photo.svg" alt="...">
                                    </div>
                                    <p>Add some quality, svg illustrations to your project courtesy of <a
                                            target="_blank" rel="nofollow" href="oncard_template/https://undraw.co/">unDraw</a>, a
                                        constantly updated collection of beautiful svg images that you can use
                                        completely free and without attribution!</p>
                                    <a target="_blank" rel="nofollow" href="oncard_template/https://undraw.co/">Browse Illustrations on
                                        unDraw &rarr;</a>
                                </div>
                            </div>

                            <!-- Approach -->
                        

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


            
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                  <div
                        class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        <h6 class="m-0 font-weight-bold text-dark"><font id="jdlmodal">Tambah Data Siswa</font></h6>
                        <div class="dropdown no-arrow">
                            <a class="dropdown-toggle text-dark" href="oncard_template/#" data-dismiss="modal">
                                <i class="fa fa-times fa-sm fa-fw text-dark-400"></i>
                            </a>
                        
                        </div>
                    </div>
                  <div class="modal-body ">
                    
                    <div class="row py-4 px-4">
                        <div class="col-md-12 col-lg-12 col-12">
                        <form id="mainx">
                            <div class="form-group" >
                                <label for="nisn">NISN</label>
                                <input type="text" class="form-control" id="nisn" placeholder="Nomor induk siswa nasional" style="width:100%;">
                            </div>
                            <div class="form-group" >
                                <label for="namakl">Nama Lengkap Siswa</label>
                                <input type="text" class="form-control" id="namakl" placeholder="Nama lengkap yang terdaftar pada data nasional" style="width:100%;">
                            </div>
                            <div class="form-group" >
                                
                                <div class="row">
                                    <div class="col-md-6 col-lg-6 col-6">
                                           <label for="" class="mr-5" style="display:block;">Jenis Kelamin</label>
                                           <div style="padding:.375rem .75rem;border-radius:.35rem; border:1px solid #d1d3e2;">
                                            <div class="form-check mr-3" style="display:inline-block;">
                                              <input class="form-check-input" type="radio" name="jkselect" id="gridRadios1" value="Laki - laki">
                                              <label class="form-check-label" for="gridRadios1">
                                                Laki - laki
                                              </label>
                                            </div>
                                            <div class="form-check" style="display:inline-block;">
                                              <input class="form-check-input" type="radio" name="jkselect" id="gridRadios2" value="Perempuan">
                                              <label class="form-check-label" for="gridRadios2">
                                                Perempuan
                                              </label>
                                            </div>
                                          </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-6">
                                           <div class="form-group" >
                                                <label for="tgllhr">Tanggal Lahir</label>
                                                <input type="date" class="form-control" id="tgllhr" placeholder="" style="width:100%;">
                                            </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="form-group" >
                                
                                <div class="row">
                                    <div class="col-md-6 col-lg-6 col-6">
                                           <label for="" class="mr-5" style="display:block;">Agama</label>
                                           <select class="form-control" id="agama" required>
                                               <option value="">Belum dipilih</option>
                                               <option value="Islam">Islam</option>
                                               <option value="Protestan">Protestan</option>
                                               <option value="Katolik">Katolik</option>
                                               <option value="Hindu">Hindu</option>
                                               <option value="Buddha">Buddha</option>
                                               <option value="Konghuchu">Konghuchu</option>
                                               <option value="Lainnya">Lainnya</option>
                                           </select>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-6">
                                           <div class="form-group" >
                                                <label for="tahunmmsk">Tahun Masuk</label>
                                                <select class="form-control" id="tahunmmsk" required>
                                                   <option value="">Belum dipilih</option>
                                                   <?php
                                                    for($x=date('Y');$x >= 1950 ;$x--){?>
                                                        <option value="<?=$x;?>"><?=$x;?></option> 
                                                   <?php } ?>
                                               </select>
                                            </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="form-group" >
                                <label for="alamat">Alamat</label>
                                <input type="text" class="form-control" id="alamat" placeholder="Alamat tempat tinggal siswa" style="width:100%;">
                            </div>
                            
                            <div class="drag-area">
                               
                                <button type="button">Pilih Foto Siswa</button>
                                <input type="file" id="uploadFile" hidden>
                                
                            </div>
                            
                        </form>
                        </div>
                    </div>
                    
                    <div class="row py-4 px-4 text-right">
                        <button type="button" class="btn btn-secondary mr-3" data-dismiss="modal">Batal</button>
                        <button type="button" id="btnSubmitForm" value="add" class="btn btn-success">Simpan Sekarang</button>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            
            
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Ponpes KH. Ahmad Dahlan - <?=date('Y');?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    

    <!--<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>-->
    <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>-->

    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/popper.min.js"></script>
    
    <!-- tambahan ego -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js" integrity="sha512-bZS47S7sPOxkjU/4Bt0zrhEtWx0y0CRkhEp8IckzK+ltifIIE9EMIMTuT/mEzoIMewUINruDBIR/jJnbguonqQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://kenwheeler.github.io/slick/slick/slick.js"></script>
    <script src="https://www.jqueryscript.net/demo/Bootstrap-4-Dropdown-Select-Plugin-jQuery/dist/js/bootstrap-select.js"></script>
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?=base_url();?>oncard_template/vendor/jquery/jquery.min.js"></script>
    <script src="<?=base_url();?>oncard_template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?=base_url();?>oncard_template/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?=base_url();?>oncard_template/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?=base_url();?>oncard_template/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?=base_url();?>oncard_template/js/demo/chart-area-demo.js"></script>
    <script src="<?=base_url();?>oncard_template/js/demo/chart-pie-demo.js"></script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.js"></script>
    <!-- ------------ -->

    <script type="text/javascript">
            
                const a = '<?=!empty($_GET["add"])?$_GET["add"]:"";?>';
                
                if(a=='true'){
                    $('#exampleModalCenter').modal('show');
                }
            
            
            var datatableset = $('#tblsiswa').DataTable( {
                // serverSide: true,
                processing: true,
                language: { search: "" ,searchPlaceholder: "Cari data siswa"},
                "oLanguage": {
                  "sInfo": "Menampilkan _START_ hingga _END_ dari _TOTAL_ total data.",
                  "oPaginate": {
                    "sPrevious": "Sebelumnya",
                    "sNext": "Berikutnya"
                  }
                },
                ajax: {
                    headers: {
                    'Accept': 'application/json','Authorization': 'Bearer '+ sessionStorage.getItem('_token')},
                    url: 'https://oncard.phoenixkreatifdigital.com/engine/api/siswa/get-table',
                    type: 'GET'
                }
                
            } );

    
        
    
        function logoutBtn() {
            sessionStorage.removeItem('_token');
            window.location.href='<?=base_url("Login/logoutUser");?>';
        }
        $(document).ready(function() {
            
        });
        
        function updateSiswa(str){
            
            $('#btnSubmitForm').val("update");
            $('#nisn').attr('disabled',true);
            
            $('#exampleModalCenter').modal('show');
            
            
            $('#jdlmodal').text("Update Data Siswa");
            
            const save = async (str)=>{
              const posts = await axios.get('https://oncard.phoenixkreatifdigital.com/engine/api/siswa/getOne?nis='+str, {
                          headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                      }).catch((err)=>{
                      
                      $(".loading").fadeOut();
                      
                      
                  });
                  
                  if(posts.status==200){
                      
                      document.getElementById("xmein").reset();
                        
                        $(".loading").fadeOut();
                        
                        $('#nisn').val(posts.data.nis);
                        $('#namakl').val(posts.data.nama_siswa);
                        $('#tgllhr').val(posts.data.tgl_lahir);
                        if($('#gridRadios1').val()==posts.data.jk){
                            $("#gridRadios1").prop("checked", true);
                        }else {
                            $("#gridRadios2").prop("checked", true);
                        }
                        $('#agama').val(posts.data.agama);
                        $('#tahunmmsk').val(posts.data.tahun_masuk);
                        $('#alamat').val(posts.data.alamat);
                      
                  }else {
                      $(".loading").fadeOut();
                      
                  }
            }
          
            save(str);
        }
        
        $('#exampleModalCenter').on('hidden.bs.modal', function () {
          $('#btnSubmitForm').val("add");
          $('#jdlmodal').text("Tambah Data Siswa");
          $('#mainx').trigger("reset");
          $('#nisn').attr('disabled',false);
        });
        
        function addSaldoSiswa(str){
            $(".loading").fadeIn();
            
            
            const save = async (str)=>{
              const posts = await axios.get('https://oncard.phoenixkreatifdigital.com/engine/api/siswa/getOne?nis='+str, {
                          headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                      }).catch((err)=>{
                      
                      $(".loading").fadeOut();
                      
                      
                  });
                  
                  if(posts.status==200){
                      if(posts.data.id_user!=null && posts.data.id_user!=undefined && posts.data.id_user!=''){
                          
                             window.location.href='<?=base_url("Manajemen/saldo/");?>'+posts.data.id_user+"/"+str;
                          
                      }else{
                              
                          $(".loading").fadeOut();
                          
                          Swal.fire({
                              position: 'center',
                              icon: 'error',
                              title: '<h6>Siswa ini belum memilik kartu oncard</h6>',
                              html: '<h6>Jadi ngga bisa deh tambahkan saldo, karena siswa ini belum ada oncard. Tambahkan sekarang?</h6>',
                              showConfirmButton: true,
                              showDenyButton: true,
                              confirmButtonText: 'Hubungkan ke Kartu',
                              denyButtonText: `Nanti saja`,
                              
                          }).then((result)=>{
                              if (result.isConfirmed) {
                                
                              } else if (result.isDenied) {
                
                              }
                            });
                      }
                    
                      
                  }else {
                      console.log('error');
                  }
            }
          
            save(str);
            
            
        }
        
        function deleteSiswa(str){
            Swal.fire({
              position: 'top',
              icon: 'info',
              title: '<h5>Yakin ingin menghapus data ini?</h5>',
              html: '<h6>Data yang telah dihapus tidak dapat dikembalikan lagi. Harap hati - hati dan teliti dalam memilih data yang ingin dihapus ya.</h6>',
              showConfirmButton: true,
              showDenyButton: true,
              showCancelButton: false,
              confirmButtonText: 'Batal menghapus',
              denyButtonText: `Yakin, hapus sekarang`,
              
            }).then((result)=>{
              if (result.isConfirmed) {
                
              } else if (result.isDenied) {

              const save = async (str)=>{
                  const posts = await axios.delete('https://oncard.phoenixkreatifdigital.com/engine/api/siswa/delete/'+str, {
                      headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                  }).catch((err)=>{
                      
                      $(".loading").fadeOut();
                      Swal.fire({
                          position: 'center',
                          icon: 'error',
                          title: 'Proses Gagal',
                          text: 'Terjadi kesalahan dalam memproses request Anda.',
                          showConfirmButton: true,
                          
                        });
                  });
                  
                  if(posts.status==200){
                      
                      if(posts.data.status==true){
                        $(".loading").fadeOut();
                        
                        Swal.fire({
                          position: 'top-center',
                          icon: 'success',
                          title: 'Dihapus!',
                          text: 'Data berhasil dihapus',
                          showConfirmButton: false,
                          timer: 2000
                          
                        });
                        
                        datatableset.ajax.reload();

                        
                      }else {
                          $(".loading").fadeOut();
                            Swal.fire({
                              position: 'center',
                              icon: 'error',
                              title: 'Gagal Proses',
                              text: 'Data tidak dapat diproses dalam saat ini, ulangi dilain waktu.',
                              showConfirmButton: true,
                              
                            });
                      }
                      
                  }else {
                      $(".loading").fadeOut();
                      
                  }
              }
              
              save(str);
              }
            });
        }
        
        
        $(".loading").hide();

        $('#btnSubmitForm').on('click', function(){
            
                    

                    $(".loading").fadeIn();
                
                
                    //validasi formulir terlebih dahulu
                    var allAreFilled = true;
                    document.getElementById("mainx").querySelectorAll("[required]").forEach(function(i) {
                      if (!allAreFilled) return;
                      if (!i.value) allAreFilled = false;
                      if (i.type === "radio") {
                        var radioValueCheck = false;
                        document.getElementById("mainx").querySelectorAll('[name=${i.name}]').forEach(function(r) {
                          if (r.checked) radioValueCheck = true;
                        })
                        allAreFilled = radioValueCheck;
                      }
                    })
                    if (!allAreFilled) {
                        Swal.fire({
                          position: 'top-end',
                          icon: 'error',
                          title: '<h6>Data tidak lengkap</h6>',
                          html: '<h6>Harap isi semua formulir inputan yang dibutuhkan.</h6>',
                          showConfirmButton: false,
                          timer: 2000
                          
                        });
                        $(".loading").fadeOut();
                    }else {
                      
                      var nisn = $("#nisn").val();
                      var namakl = $("#namakl").val();
                      var tgllhr = $("#tgllhr").val();
                      var agama = $("#agama").val();
                      var tahunmmsk = $("#tahunmmsk").val();
                      var alamat = $("#alamat").val();
                      var file_data = $('#uploadFile').prop('files')[0];
                      var getjk = $('input[name="jkselect"]:checked').val();
                      
                      
                      var form_data = new FormData();    
                      form_data.append('filesss', file_data);
                      form_data.append('nis', nisn);
                      form_data.append('nama_siswa', namakl);
                      form_data.append('tgl_lahir', tgllhr);
                      form_data.append('agama', agama);
                      form_data.append('tahun_masuk', tahunmmsk);
                      form_data.append('alamat', alamat);
                      form_data.append('jk', getjk);
                      form_data.append('kelas', '-');
                      
                      
                      var url = "";
                      if($("#btnSubmitForm").val()=='add'){
                          url = 'https://oncard.phoenixkreatifdigital.com/engine/api/siswa/create';
                      }else {
                          url = 'https://oncard.phoenixkreatifdigital.com/engine/api/siswa/update';
                      }
                     
                      const save = async (form_data)=>{
                          const posts = await axios.post(url, form_data, {
                              headers: {'Authorization': 'Bearer '+ sessionStorage.getItem('_token')}
                          }).catch((err)=>{
                              
                              $(".loading").fadeOut();
                              Swal.fire({
                                  position: 'center',
                                  icon: 'error',
                                  title: 'Gagal Menyimpan',
                                  text: 'Terjadi kesalahan dalam proses data.',
                                  showConfirmButton: true,
                                  
                                });
                          });
                          
                          if(posts.status==200){
                              
                              if(posts.data.status==true){
                                $(".loading").fadeOut();
                    
                    
                    
                                Swal.fire({
                                  position: 'top-end',
                                  icon: 'success',
                                  title: '<h6>Berhasil Menyimpan</h6>',
                                  html: '<h6>Data sudah tersimpan</h6>',
                                  showConfirmButton: false,
                                  timer: 2000
                                  
                                });
                                
                                // $('#tblsiswa').ajax.reload();
                                datatableset.ajax.reload();
                                
                              }else {
                                  $(".loading").fadeOut();
                                Swal.fire({
                                  position: 'center',
                                  icon: 'error',
                                  title: 'Gagal Menyimpan',
                                  text: 'Data tidak dapat disimpan dalam saat ini, ulangi dilain waktu.',
                                  showConfirmButton: true,
                                  
                                });
                              }
                              
                          }else {
                              $(".loading").fadeOut();
                              Swal.fire({
                                  position: 'center',
                                  icon: 'error',
                                  title: 'Gagal Menyimpan',
                                  text: 'Data sudah ada dan tidak dapat ditambahkan lagi',
                                  showConfirmButton: true,
                                  
                                });
                          }
                      }
                      
                      save(form_data);
   
                    }

        });
        
        $("#errmsgs").fadeOut();

    </script>

</body>
<!-- Mirrored from colorlib.com/polygon/admindek/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Dec 2019 16:08:25 GMT -->

</html>